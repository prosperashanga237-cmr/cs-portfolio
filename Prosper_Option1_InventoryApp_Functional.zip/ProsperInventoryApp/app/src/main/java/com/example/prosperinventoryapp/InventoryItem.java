package com.example.prosperinventoryapp;

/**
 * Simple data holder for one row of the "items" table. Keeping this as its
 * own small class (instead of passing raw Cursor data around) is what lets
 * the RecyclerView adapter and the database helper stay decoupled.
 */
public class InventoryItem {

    private final long id;
    private final String name;
    private final int quantity;

    public InventoryItem(long id, String name, int quantity) {
        this.id = id;
        this.name = name;
        this.quantity = quantity;
    }

    public long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public int getQuantity() {
        return quantity;
    }
}
