package com.example.prosperinventoryapp;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;

/**
 * Handles the SMS Notifications requirement end to end:
 *  - Requests the SEND_SMS runtime permission (and reflects whatever the
 *    user chooses, granted or denied, back on screen).
 *  - Lets the user save the phone number that low-stock alerts go to.
 *
 * This screen never blocks the rest of the app: if the user denies the
 * permission, InventoryActivity keeps working normally and simply skips
 * sending texts (see SmsAlertHelper).
 */
public class NotificationSettingsActivity extends AppCompatActivity {

    private TextView permissionStatusText;
    private TextInputEditText phoneNumberInput;

    private final ActivityResultLauncher<String> requestPermissionLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), granted ->
                    updatePermissionStatus(granted));

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notification_settings);

        permissionStatusText = findViewById(R.id.permissionStatusText);
        phoneNumberInput = findViewById(R.id.phoneNumberInput);

        MaterialButton requestPermissionButton = findViewById(R.id.requestPermissionButton);
        MaterialButton savePhoneButton = findViewById(R.id.savePhoneButton);

        requestPermissionButton.setOnClickListener(v -> requestSmsPermission());
        savePhoneButton.setOnClickListener(v -> savePhoneNumber());

        String savedNumber = SmsAlertHelper.getSavedPhoneNumber(this);
        if (!savedNumber.isEmpty()) {
            phoneNumberInput.setText(savedNumber);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Reflect the real, current permission state every time this
        // screen is shown (e.g. if it was changed from Android's app
        // settings screen instead of this activity's own button).
        refreshStatusFromCurrentPermission();
    }

    private void requestSmsPermission() {
        boolean alreadyGranted = SmsAlertHelper.hasSmsPermission(this);
        if (alreadyGranted) {
            updatePermissionStatus(true);
            return;
        }
        requestPermissionLauncher.launch(Manifest.permission.SEND_SMS);
    }

    private void refreshStatusFromCurrentPermission() {
        boolean granted = ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED;
        if (granted) {
            updatePermissionStatus(true);
        } else {
            permissionStatusText.setText(R.string.status_permission_unknown);
        }
    }

    private void updatePermissionStatus(boolean granted) {
        permissionStatusText.setText(granted
                ? R.string.status_permission_granted
                : R.string.status_permission_denied);
    }

    private void savePhoneNumber() {
        String number = phoneNumberInput.getText() == null
                ? "" : phoneNumberInput.getText().toString().trim();
        SmsAlertHelper.savePhoneNumber(this, number);
        Toast.makeText(this, R.string.toast_phone_saved, Toast.LENGTH_SHORT).show();
    }
}
