package com.example.prosperinventoryapp;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;

/**
 * Lets a first-time user create a username/password and saves it to the
 * "users" table. On success, logs them straight into the inventory screen
 * rather than bouncing them back to the login form.
 */
public class RegisterActivity extends AppCompatActivity {

    private DatabaseHelper databaseHelper;

    private TextInputEditText usernameInput;
    private TextInputEditText passwordInput;
    private TextInputEditText confirmPasswordInput;
    private TextView registerErrorText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        databaseHelper = new DatabaseHelper(this);

        usernameInput = findViewById(R.id.regUsernameInput);
        passwordInput = findViewById(R.id.regPasswordInput);
        confirmPasswordInput = findViewById(R.id.regConfirmPasswordInput);
        registerErrorText = findViewById(R.id.registerErrorText);

        MaterialButton createAccountButton = findViewById(R.id.createAccountButton);
        createAccountButton.setOnClickListener(this::onCreateAccountClicked);
    }

    private void onCreateAccountClicked(View view) {
        String username = textOf(usernameInput);
        String password = textOf(passwordInput);
        String confirmPassword = textOf(confirmPasswordInput);

        if (TextUtils.isEmpty(username) || TextUtils.isEmpty(password)) {
            showError(R.string.error_empty_fields);
            return;
        }

        if (!password.equals(confirmPassword)) {
            showError(R.string.error_passwords_mismatch);
            return;
        }

        boolean created = databaseHelper.registerUser(username, password);
        if (!created) {
            showError(R.string.error_username_taken);
            return;
        }

        registerErrorText.setVisibility(View.INVISIBLE);
        Toast.makeText(this, getString(R.string.toast_account_created, username),
                Toast.LENGTH_SHORT).show();

        Intent intent = new Intent(RegisterActivity.this, InventoryActivity.class);
        startActivity(intent);
        // Clear the whole login/register back-stack now that the user is signed in.
        finish();
    }

    private void showError(int messageResId) {
        registerErrorText.setText(messageResId);
        registerErrorText.setVisibility(View.VISIBLE);
    }

    private String textOf(TextInputEditText editText) {
        return editText.getText() == null ? "" : editText.getText().toString().trim();
    }
}
