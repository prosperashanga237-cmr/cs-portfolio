package com.example.prosperinventoryapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import java.util.List;

/**
 * Main screen after login. Shows every inventory item in a 2-column grid
 * backed directly by SQLite (DatabaseHelper), and supports the full
 * Create/Read/Update/Delete set required by the project:
 *  - Create: the FAB opens AddItemActivity.
 *  - Read: onResume() reloads and displays every row.
 *  - Update: the +/- buttons on each card change that item's quantity.
 *  - Delete: the trash icon removes an item after a confirmation dialog.
 *
 * When an item's quantity is decreased to zero, this also triggers the
 * low-stock SMS alert (SmsAlertHelper), which itself is a no-op if the user
 * never granted SMS permission - so this screen never depends on that
 * permission to keep working.
 */
public class InventoryActivity extends AppCompatActivity implements InventoryAdapter.Listener {

    private DatabaseHelper databaseHelper;
    private InventoryAdapter adapter;
    private RecyclerView recyclerView;
    private TextView emptyStateText;
    private View rootView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        databaseHelper = new DatabaseHelper(this);

        Toolbar toolbar = findViewById(R.id.inventoryToolbar);
        setSupportActionBar(toolbar);

        rootView = findViewById(android.R.id.content);
        emptyStateText = findViewById(R.id.emptyStateText);
        recyclerView = findViewById(R.id.inventoryRecyclerView);
        recyclerView.setLayoutManager(new GridLayoutManager(this, 2));

        adapter = new InventoryAdapter(this);
        recyclerView.setAdapter(adapter);

        FloatingActionButton addItemFab = findViewById(R.id.addItemFab);
        addItemFab.setOnClickListener(v ->
                startActivity(new Intent(InventoryActivity.this, AddItemActivity.class)));
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Re-read from the database every time the screen becomes visible,
        // so changes made in AddItemActivity (or a previous session) show
        // up immediately. This is the "Read" half of CRUD.
        refreshItems();
    }

    private void refreshItems() {
        List<InventoryItem> items = databaseHelper.getAllItems();
        adapter.submitList(items);
        emptyStateText.setVisibility(items.isEmpty() ? View.VISIBLE : View.GONE);
        recyclerView.setVisibility(items.isEmpty() ? View.GONE : View.VISIBLE);
    }

    @Override
    public void onIncreaseClicked(InventoryItem item) {
        databaseHelper.updateItemQuantity(item.getId(), item.getQuantity() + 1);
        refreshItems();
    }

    @Override
    public void onDecreaseClicked(InventoryItem item) {
        int newQuantity = Math.max(0, item.getQuantity() - 1);
        databaseHelper.updateItemQuantity(item.getId(), newQuantity);
        refreshItems();

        if (newQuantity == 0) {
            onItemOutOfStock(item.getName());
        }
    }

    @Override
    public void onDeleteClicked(InventoryItem item) {
        new AlertDialog.Builder(this)
                .setTitle(R.string.dialog_delete_title)
                .setMessage(getString(R.string.dialog_delete_message, item.getName()))
                .setPositiveButton(R.string.btn_delete, (dialog, which) -> {
                    databaseHelper.deleteItem(item.getId());
                    refreshItems();
                })
                .setNegativeButton(R.string.btn_cancel, null)
                .show();
    }

    /**
     * The "low inventory" notification trigger: shows an on-screen Snackbar
     * every time (so the user always sees it), and additionally fires an
     * SMS alert when permission and a phone number are both configured.
     */
    private void onItemOutOfStock(String itemName) {
        Snackbar.make(rootView, getString(R.string.snackbar_out_of_stock, itemName),
                Snackbar.LENGTH_LONG).show();
        SmsAlertHelper.sendLowStockAlert(this, itemName);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_inventory, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.action_notification_settings) {
            startActivity(new Intent(this, NotificationSettingsActivity.class));
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
