package com.example.prosperinventoryapp;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;

/**
 * Simple form for the "Create" half of the inventory CRUD requirement.
 * Inserts one new row into the items table and returns to the grid, which
 * reloads automatically in InventoryActivity#onResume().
 */
public class AddItemActivity extends AppCompatActivity {

    private DatabaseHelper databaseHelper;

    private TextInputEditText nameInput;
    private TextInputEditText quantityInput;
    private TextView errorText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_item);

        databaseHelper = new DatabaseHelper(this);

        nameInput = findViewById(R.id.itemNameInput);
        quantityInput = findViewById(R.id.itemQuantityInput);
        errorText = findViewById(R.id.addItemErrorText);

        MaterialButton saveButton = findViewById(R.id.saveItemButton);
        saveButton.setOnClickListener(this::onSaveClicked);
    }

    private void onSaveClicked(View view) {
        String name = nameInput.getText() == null ? "" : nameInput.getText().toString().trim();
        String quantityText = quantityInput.getText() == null ? "" : quantityInput.getText().toString().trim();

        if (TextUtils.isEmpty(name)) {
            showError(R.string.error_item_name_required);
            return;
        }

        if (TextUtils.isEmpty(quantityText)) {
            showError(R.string.error_quantity_required);
            return;
        }

        int quantity;
        try {
            quantity = Integer.parseInt(quantityText);
        } catch (NumberFormatException e) {
            showError(R.string.error_quantity_required);
            return;
        }

        if (quantity < 0) {
            showError(R.string.error_quantity_required);
            return;
        }

        databaseHelper.addItem(name, quantity);
        finish();
    }

    private void showError(int messageResId) {
        errorText.setText(messageResId);
        errorText.setVisibility(View.VISIBLE);
    }
}
