package com.example.prosperinventoryapp;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;

/**
 * Entry point of the app (launcher activity). Checks an entered
 * username/password against the "users" table in SQLite; on success, moves
 * on to the inventory grid. Users with no account yet can tap through to
 * RegisterActivity to create one.
 */
public class LoginActivity extends AppCompatActivity {

    private DatabaseHelper databaseHelper;

    private TextInputEditText usernameInput;
    private TextInputEditText passwordInput;
    private TextView loginErrorText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        databaseHelper = new DatabaseHelper(this);

        usernameInput = findViewById(R.id.usernameInput);
        passwordInput = findViewById(R.id.passwordInput);
        loginErrorText = findViewById(R.id.loginErrorText);

        MaterialButton loginButton = findViewById(R.id.loginButton);
        TextView goToRegisterText = findViewById(R.id.goToRegisterText);

        loginButton.setOnClickListener(this::onLoginClicked);
        goToRegisterText.setOnClickListener(v ->
                startActivity(new Intent(LoginActivity.this, RegisterActivity.class)));
    }

    private void onLoginClicked(View view) {
        String username = textOf(usernameInput);
        String password = textOf(passwordInput);

        if (TextUtils.isEmpty(username) || TextUtils.isEmpty(password)) {
            showError(R.string.error_empty_fields);
            return;
        }

        if (!databaseHelper.validateUser(username, password)) {
            showError(R.string.error_invalid_login);
            return;
        }

        loginErrorText.setVisibility(View.INVISIBLE);
        Intent intent = new Intent(LoginActivity.this, InventoryActivity.class);
        startActivity(intent);
        // The user shouldn't be able to go "back" into the login screen
        // once they're signed in.
        finish();
    }

    private void showError(int messageResId) {
        loginErrorText.setText(messageResId);
        loginErrorText.setVisibility(View.VISIBLE);
    }

    private String textOf(TextInputEditText editText) {
        return editText.getText() == null ? "" : editText.getText().toString().trim();
    }
}
