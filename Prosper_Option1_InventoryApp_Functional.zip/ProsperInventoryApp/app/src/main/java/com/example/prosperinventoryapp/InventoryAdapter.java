package com.example.prosperinventoryapp;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.button.MaterialButton;

import java.util.ArrayList;
import java.util.List;

/**
 * Binds the list of InventoryItem objects to the grid's RecyclerView. All
 * the actual database work happens in InventoryActivity (via the Listener
 * callbacks below) so this class only knows about displaying data and
 * forwarding taps - keeping it small and easy to read, per the project's
 * "keep classes concise" best-practice guideline.
 */
public class InventoryAdapter extends RecyclerView.Adapter<InventoryAdapter.ItemViewHolder> {

    /** Callback interface the hosting Activity implements to react to taps. */
    public interface Listener {
        void onIncreaseClicked(InventoryItem item);
        void onDecreaseClicked(InventoryItem item);
        void onDeleteClicked(InventoryItem item);
    }

    private final List<InventoryItem> items = new ArrayList<>();
    private final Listener listener;

    public InventoryAdapter(Listener listener) {
        this.listener = listener;
    }

    /** Replaces the whole list and refreshes the grid. Called after every DB change. */
    public void submitList(List<InventoryItem> newItems) {
        items.clear();
        items.addAll(newItems);
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ItemViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_inventory, parent, false);
        return new ItemViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull ItemViewHolder holder, int position) {
        InventoryItem item = items.get(position);

        holder.nameText.setText(item.getName());
        holder.quantityText.setText(
                holder.itemView.getContext().getString(R.string.item_quantity_format, item.getQuantity()));

        holder.increaseButton.setOnClickListener(v -> listener.onIncreaseClicked(item));
        holder.decreaseButton.setOnClickListener(v -> listener.onDecreaseClicked(item));
        holder.deleteButton.setOnClickListener(v -> listener.onDeleteClicked(item));
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    static class ItemViewHolder extends RecyclerView.ViewHolder {
        final TextView nameText;
        final TextView quantityText;
        final MaterialButton increaseButton;
        final MaterialButton decreaseButton;
        final ImageButton deleteButton;

        ItemViewHolder(@NonNull View itemView) {
            super(itemView);
            nameText = itemView.findViewById(R.id.itemNameText);
            quantityText = itemView.findViewById(R.id.itemQuantityText);
            increaseButton = itemView.findViewById(R.id.increaseButton);
            decreaseButton = itemView.findViewById(R.id.decreaseButton);
            deleteButton = itemView.findViewById(R.id.deleteButton);
        }
    }
}
