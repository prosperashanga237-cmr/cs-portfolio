package com.example.prosperinventoryapp;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.telephony.SmsManager;
import android.util.Log;
import android.widget.Toast;

import androidx.core.content.ContextCompat;

/**
 * Sends the "item is out of stock" SMS alert used by the Database section's
 * low-inventory trigger. This is intentionally a small static-method helper
 * (not an Activity) so InventoryActivity can call it in one line without
 * needing to know anything about permissions or preferences itself.
 *
 * If the user never granted SEND_SMS, or never entered a phone number in
 * Notification Settings, this quietly does nothing instead of crashing or
 * blocking the rest of the app - matching the "app keeps working if the
 * user denies permission" requirement.
 */
public final class SmsAlertHelper {

    private static final String TAG = "CS360_SmsAlertHelper";
    public static final String PREFS_NAME = "notification_prefs";
    public static final String KEY_PHONE_NUMBER = "alert_phone_number";

    private SmsAlertHelper() {
        // Utility class: no instances.
    }

    public static boolean hasSmsPermission(Context context) {
        return ContextCompat.checkSelfPermission(context, android.Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED;
    }

    public static void savePhoneNumber(Context context, String phoneNumber) {
        getPrefs(context).edit().putString(KEY_PHONE_NUMBER, phoneNumber).apply();
    }

    public static String getSavedPhoneNumber(Context context) {
        return getPrefs(context).getString(KEY_PHONE_NUMBER, "");
    }

    private static SharedPreferences getPrefs(Context context) {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
    }

    /**
     * Sends a low-stock text alert for the given item name, if (and only
     * if) permission has been granted and a phone number has been saved.
     * Returns true if an SMS send was attempted.
     */
    public static boolean sendLowStockAlert(Context context, String itemName) {
        if (!hasSmsPermission(context)) {
            Log.d(TAG, "Skipping SMS alert: SEND_SMS permission not granted.");
            return false;
        }

        String phoneNumber = getSavedPhoneNumber(context);
        if (phoneNumber == null || phoneNumber.trim().isEmpty()) {
            Log.d(TAG, "Skipping SMS alert: no phone number saved in Notification Settings.");
            return false;
        }

        String message = context.getString(R.string.snackbar_out_of_stock, itemName);

        try {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);
            Log.d(TAG, "Low-stock SMS sent for " + itemName + " to " + phoneNumber);
            Toast.makeText(context,
                    context.getString(R.string.toast_sms_sent, itemName),
                    Toast.LENGTH_SHORT).show();
            return true;
        } catch (Exception e) {
            // Emulators without a simulated SIM/radio can throw here; the
            // rest of the app must keep working regardless.
            Log.e(TAG, "Failed to send low-stock SMS", e);
            Toast.makeText(context, R.string.toast_sms_failed, Toast.LENGTH_SHORT).show();
            return false;
        }
    }
}
